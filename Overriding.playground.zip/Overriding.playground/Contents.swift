import UIKit

class Hayvan {
    func sesCikar(){
        print ("Sesim yok")
    }
    
    
}

class Memeli :Hayvan {
    
    
    
}


class Kedi :Memeli {
    override func sesCikar() {
print ("Miyav Miyav")    }
    
    
}


class Kopek :Memeli {
    override func sesCikar() {
        print ("Hav Hav")
    }
    
}


let hayvan = Hayvan()
let memeli = Memeli()
let kedi = Kedi()
let kopek = Kopek()


hayvan.sesCikar()  //Katılım yok ve kendi fonksiyonunu çalıştırdı, nesne ile erişim sağladı.
memeli.sesCikar() //Kendi classı içinde yok ve bir üst class yani hayvan class içine giderek çalıştırdı. Burada asıl mantık önce kendi içerisine bakar, eğer kendi içerisinde yoksa bir üst sınıfın içerisine giderek burada olanı çalıştırır. Burada devreye katılım girer ve bir üst sınıfın nesnesini çalıştırır. Bu yüzden ekranda sesim yok yazdırdı.
kedi.sesCikar() //Burada katılım var ama yine de ekranda miyav diye kendi metodunu çalıştırdı. Katılım olduğunu da memelinden aldığını ve overide olarak çalıştırdı.
kopek.sesCikar() //Burada katılım var ama yine de ekranda hav diye kendi metodunu çalıştırdı. Katılım olduğunu da memelinden aldığını ve overide olarak çalıştırdı.
